package uts.isd.model.dao;

import uts.isd.model.Student;
import java.sql.*;

/**
 *
 * @author George
 * 
 * DBManager is the primary DAO class to interact with the database and perform CRUD operations with the db.
 * Firstly, complete the existing methods and implement them into the application.
 * 
 * So far the application uses the Read and Create operations in the view.
 * Secondly, improve the current view to enable the Update and Delete operations.
 */
public class DBManager {

    private Statement st;

    public DBManager(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

    //Find student by ID in the database
    public Student findStudent(String ID, String password) throws SQLException {
        //setup the select sql query string
        String searchQueryString = "select * from Students where ID='" + ID + "' AND password='" + password + "'";
        //execute this query using the statement field
       //add the results to a ResultSet
         ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a student using the parameters
         boolean hasStudent = rs.next();
         Student studentFromDB = null;
                 
         if(hasStudent){
         
             String sID = rs.getString("ID");
             String sName = rs.getString("name");
             String sEmail = rs.getString("email");
             String sPassword = rs.getString("password"); 
             String sDOB = rs.getString("dob");
             String sPhonenum = rs.getString("phonenum");
             
             studentFromDB = new Student (sID, sName, sEmail, sPassword, sDOB, sPhonenum);
         }
        
         rs.close();
        // st.close();
         
         return studentFromDB;
         
    }

    //Check if a student exist in the database
    public boolean checkStudent(String ID, String password) throws SQLException {
       //setup the select sql query string
        //execute this query using the statement field
        //add the results to a ResultSet
        //search the ResultSet for a student using the parameters
        //verify if the student exists
        return false;
    }

    //Add a student-data into the database
    public void addStudent(String ID, String name, String email, String password, String dob, String phonenum) throws SQLException {        
        //code for add-operation
        
         String createQueryString = "insert into Students" + " values ('" + ID + "', '" + name + "', '" + email + "', '" + password + "', '" + dob + "', '" + phonenum + "')";
         boolean recrodCreated = st.executeUpdate(createQueryString) > 0;
         
         if (recrodCreated){
         System.out.println("record created");
         }
         else {
         System.out.println("record not created");
         }
             
    }

    //update a student details in the database
    public void updateStudent(String ID, String name, String email, String password, String dob, String phonenum) throws SQLException {
        //code for update-operation
        
        String updateQueryString = "update Students set name = '" + name + "', email= '" + email + "', password = '"  + password + "', dob = '" + dob + "', phonenum = '" + phonenum + "' where ID='" + ID + "'";
        boolean recrodUpdated = st.executeUpdate(updateQueryString) > 0;
         
         if (recrodUpdated){
         System.out.println("record updated");
         }
         else {
         System.out.println("record not updated");
         }
       
    }
    
    //delete a student from the database
    public void deleteStudent(String ID) throws SQLException{
        //code for delete-operation
        
        String deleteQueryString = "delete from Students where ID= '" + ID + "' ";
        boolean recrodDeleted = st.executeUpdate(deleteQueryString) > 0;
         
         if (recrodDeleted){
         System.out.println("record deleted");
         }
         else {
         System.out.println("record not deleted");
         }
    }
}
